<?php

namespace Database\Factories;

use App\Models\Order;
use Illuminate\Database\Eloquent\Factories\Factory;

class OrderFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Order::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $foodItems = [
            'Burger',
            'Pizza',
            'Sandwich',
            'Salad',
            'Pasta',
            'Sushi',
            'Taco',
            'Wrap',
            'Soup',
            'Fried Chicken',
        ];
        return [
            'Date of Order' => $this->faker->words(3, true), // Generate a random product name.
            // list of strings that are names of foods gotten from a cafetiaria
            'items' => $this->faker->randomElements($foodItems, $this->faker->numberBetween(1, 5)), // Generate a random product name.
            'total_price' => $this->faker->randomFloat(2, 10, 1000), // Generate a random total price with 2 decimal places between 10 and 1000.
            'status' => $this->faker->randomElement(['En Route', 'Preparing', 'Completed']), // Generate a random status from the array ['pending', 'processing', 'completed'].
            'uid' => function () {
                // Optionally, you can associate orders with users here.
                // Replace this with your logic to assign a user ID to the order.
                // For example, you can use User::inRandomOrder()->first()->id to assign a random user ID.
                return null;
            },
        ];
    }
}