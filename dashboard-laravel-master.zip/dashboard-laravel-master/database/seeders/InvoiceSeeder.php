<?php


namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Order;
use Faker\Factory as Faker;

class InvoiceSeeder extends Seeder
{
    public function run()
    {
        $faker = Faker::create();

        // Generate invoices for existing orders
        $orders = Order::all();

        foreach ($orders as $order) {
            DB::table('invoices')->insert([
            'order_id' => $order->id,
            'invoice_total' => $order->total_price,
            'invoice_date' => $order->Date_of_Order,
            'created_at' => now(),
            
        ]);
            // Invoice::create([
            //     'order_id' => $order->id,
            //     'invoice_total' => $faker->randomFloat(2, 10, 200),
            //     'invoice_date' => $faker->date,
            // ]);
        }
    }
}