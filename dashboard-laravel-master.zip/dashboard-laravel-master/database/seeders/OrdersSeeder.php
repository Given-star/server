<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class OrdersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $foodItems = [
            'Burger',
            'Pizza',
            'Sandwich',
            'Salad',
            'Pasta',
            'Sushi',
            'Taco',
            'Wrap',
            'Soup',
            'Fried Chicken',
        ];

        DB::table('orders')->insert([
            'Date_of_Order' => now(),
            'items' => json_encode(['Pizza', 'Pasta', 'Wrap']),
            'total_price' => 30.99,
            'status' => 'En Route',
            'uid' => 1, // Replace with the user ID associated with this order.
            'created_at' => now(),
            
        ]);

        DB::table('orders')->insert([
            'Date_of_Order' => now(),
            'items' => json_encode(['Pizza', 'Wrap', 'Samoosa']),
            'total_price' => 25.99,
            'status' => 'Preparing',
            'uid' => 2, // Replace with the user ID associated with this order.
            'created_at' => now(),
            
        ]);

        DB::table('orders')->insert([
            'Date_of_Order' => now(),
            'items' => json_encode(['Wrap', 'Salad', 'Chicken']),
            'total_price' => 20.99,
            'status' => 'Completed',
            'uid' => 3, // Replace with the user ID associated with this order.
            'created_at' => now(),
            
        ]);

        // Order 4
        DB::table('orders')->insert([
            'Date_of_Order' => now(),
            'items' => json_encode(['Burger', 'Salad', 'Soup']),
            'total_price' => 15.99,
            'status' => 'En Route',
            'uid' => 4, // Replace with the user ID associated with this order.
            'created_at' => now(),
        ]);

        // Order 5
        DB::table('orders')->insert([
            'Date_of_Order' => now(),
            'items' => json_encode(['Taco', 'Sushi', 'Wrap']),
            'total_price' => 19.99,
            'status' => 'Preparing',
            'uid' => 5, // Replace with the user ID associated with this order.
            'created_at' => now(),
        ]);

        // Order 6
        DB::table('orders')->insert([
            'Date_of_Order' => now(),
            'items' => json_encode(['Sandwich', 'Salad', 'Pasta']),
            'total_price' => 22.50,
            'status' => 'En Route',
            'uid' => 6, // Replace with the user ID associated with this order.
            'created_at' => now(),
        ]);

        // Continue adding more orders as needed...

        // Order N
        DB::table('orders')->insert([
            'Date_of_Order' => now(),
            'items' => json_encode(['Fried Chicken', 'Sushi', 'Salad']),
            'total_price' => 35.75,
            'status' => 'Completed',
            'uid' => 7, // Replace with the user ID associated with this order.
            'created_at' => now(),
        ]);

        DB::table('orders')->insert([
    'Date_of_Order' => now(),
    'items' => json_encode(['Burger', 'Pizza', 'Sushi']),
    'total_price' => 27.50,
    'status' => 'Preparing',
    'uid' => 8, // Replace with the user ID associated with this order.
    'created_at' => now(),
]);

// Order 8
DB::table('orders')->insert([
    'Date_of_Order' => now(),
    'items' => json_encode(['Taco', 'Wrap', 'Salad']),
    'total_price' => 18.25,
    'status' => 'En Route',
    'uid' => 9, // Replace with the user ID associated with this order.
    'created_at' => now(),
]);

// Order 9
DB::table('orders')->insert([
    'Date_of_Order' => now(),
    'items' => json_encode(['Pasta', 'Samoosa', 'Soup']),
    'total_price' => 14.99,
    'status' => 'Completed',
    'uid' => 10, // Replace with the user ID associated with this order.
    'created_at' => now(),
]);

// Order 10
DB::table('orders')->insert([
    'Date_of_Order' => now(),
    'items' => json_encode(['Pizza', 'Sandwich', 'Fried Chicken']),
    'total_price' => 24.75,
    'status' => 'Preparing',
    'uid' => 11, // Replace with the user ID associated with this order.
    'created_at' => now(),
]);

        

        // Add more orders as needed...
    }
}