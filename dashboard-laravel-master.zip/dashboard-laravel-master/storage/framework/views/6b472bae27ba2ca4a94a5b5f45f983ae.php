<?php echo e($slot); ?>

<?php /**PATH C:\Dev\Github\Laravel\soft-ui-dashboard-laravel-master\soft-ui-dashboard-laravel-master\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>