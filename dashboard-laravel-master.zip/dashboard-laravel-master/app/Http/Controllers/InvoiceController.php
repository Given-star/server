<?php

namespace App\Http\Controllers;
use App\Models\Invoice; // Import the Invoice model
use Illuminate\Http\Request;


class InvoiceController extends Controller
{
    public function index()
    {
        $invoices = Invoice::all();
        return view('invoices', ['invoices' => $invoices]);
    }

    public function show($id)
    {
        $invoice = Invoice::find($id);
        if (!$invoice) {
            return redirect()->route('invoice.index')->with('error', 'Invoice not found.');
        }
        return view('invoices.show', ['invoices' => $invoice]);
    }

    public function create()
    {
        // Logic to load create invoice form (if needed)
    }

    public function store(Request $request)
    {
        // Validation and logic to store a new invoice
    }

    public function edit($id)
    {
        // Logic to load edit invoice form (if needed)
    }

    public function update(Request $request, $id)
    {
        // Validation and logic to update an invoice
    }

    public function destroy($id)
    {
        // Logic to delete an invoice
    }
}