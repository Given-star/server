<?php

namespace App\Http\Controllers;
use App\Models\Order; // Import the Order model

use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index()
    {
        // Retrieve all orders from the database
        $orders = Order::all();

        // Pass the orders data to the view
        return view('orders', compact('orders'));
    }
    public function updateStatus(Request $request, $id)
{
    // Get the order record by its ID
    $order = Order::find($id);

    if (!$order) {
        // Handle the case where the order is not found
        return redirect()->route('orders.index')->with('error', 'Order not found.');
    }

    // Validate the request data (you can add more validation rules)
    $validatedData = $request->validate([
        'status' => 'required|in:En Route,Preparing,Completed', // Assuming 'status' is the field you want to update
    ]);

    // Update the 'status' field
    $order->update([
        'status' => $validatedData['status'],
    ]);

    // Redirect back with a success message
    return redirect()->route('orders.index')->with('success', 'Order status updated successfully.');
}
}